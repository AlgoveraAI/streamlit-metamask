# 🦊 Streamlit MetaMask component

This repository contains the code behind the Streamlit MetaMask component that you can use to turn your Streamlit apps into dapps.
